import AdminOverview from "@/components/admin/overview"

export default function AdminDashboardPage() {
  return <AdminOverview />
}
